#include<iostream>

using namespace std;

int main() {
	cout << "=========================" << endl;
	cout << "| Name: Lee Chi Jui     |" << endl;
	cout << "| Student ID: E24091019 |" << endl;
	cout << "| Birthday: 11/25       |" << endl;
	cout << "=========================" << endl;
	return 0;
}