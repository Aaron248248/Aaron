#include <iostream>
using namespace std;

int main()
{
	cout << "= = = = = = = = = = = = = = =\n";
	cout << "| Julian                    |\n";
	cout << "| mobile:0919....           |\n";
	cout << "| email:Julian...@gmail...  |\n";
	cout << "| web:https://.........     |\n";
	cout << "| address:.......           |\n";
	cout << "= = = = = = = = = = = = = = =\n";
}